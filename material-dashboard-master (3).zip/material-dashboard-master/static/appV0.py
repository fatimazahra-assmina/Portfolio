from flask import send_file, send_from_directory
import os
import json
from flask import Flask, render_template, request
from pdf_summarizer import (summarize, find_related_pdfs, extract_text_from_pdf)

app = Flask(__name__, template_folder='material-dashboard-master/Templates')
#app1 = Flask(__name__, static_url_path='/static', static_folder='static')
#app2 = Flask(__name__, assets_url_path='static/assets', static_folder='assets')

@app.route('/')
def ggl_search():
    return render_template('GGL_Search.html')

@app.route('/sanamed_home')
def sanamed_home():
    return render_template('Home-page.html')


@app.route('/doc_synthesis')
def doc_synthesis():
    return render_template('Synthesis-doc.html')

@app.route('/signin')
def signin():
    return render_template('sign-in.html')

@app.route('/tableau_de_bord')
def tableau_de_bord():
    return render_template('dashboard.html')

@app.route('/profile')
def profile():
    return render_template('profile.html')

@app.route('/download_pdf/<filename>')
def download_pdf(filename):
    pdf_path = os.path.join("Patients/DMP Jean DUPONT", filename)
    return send_file(pdf_path, as_attachment=True)

@app.route('/picture/<path:filename>')
def get_picture(filename):
    return send_from_directory('/static', filename)

@app.route('/picture1/<path:filename>')
def get_picture1(filename):
    return send_from_directory('/assets', filename)

@app.route('/search', methods=['POST'])
def search():
    query = request.form.get("query")
    directory = "DMP Jean DUPONT"
    related_pdfs = find_related_pdfs(query, directory)
    results = []
    for match in related_pdfs:
        pdf_path = match["file_path"]
        pdf_content = extract_text_from_pdf(pdf_path)
        summary = summarize(pdf_content)
        result = {
            "title": match["file_name"],
            "date": match["date de la consultation"],
            "summary": match["relatable_sentence"],
            "pdf_url": f"/download_pdf/{match['file_name']}"
        }
        results.append(result)
    return json.dumps(results)
    #return render_template('results.html', results=results)


if __name__ == '__main__':

    app.run(debug=True)