import PyPDF4
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from collections import defaultdict
from heapq import nlargest

import string
from datetime import datetime
import os
import spacy
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import io
from pdfminer.converter import TextConverter
from pdfminer.pdfinterp import PDFPageInterpreter
from pdfminer.pdfinterp import PDFResourceManager
from pdfminer.pdfpage import PDFPage

#IF THE CODE SHOWS SOME ERRORS WHILE BEING RAN (NLTK ERRORS). TRY TO RUN THE FOLLOWING LINES BELLOW.

nltk.download('punkt')
nltk.download('stopwords')
nlp = spacy.load("fr_core_news_md")


# Function to extract text from a PDF ( to read a PDF):

def extract_text_from_pdf(pdf_path):
    text = ""
    with open(pdf_path, "rb") as file:
        resource_manager = PDFResourceManager()
        fake_file_handle = io.StringIO()
        converter = TextConverter(resource_manager, fake_file_handle)
        page_interpreter = PDFPageInterpreter(resource_manager, converter)

        for page in PDFPage.get_pages(file, caching=True, check_extractable=True):
            page_interpreter.process_page(page)

        text = fake_file_handle.getvalue()

        converter.close()
        fake_file_handle.close()

    return text


# Function to summarize text
def summarize(text: str) -> str:
    # Tokenize the text
    tokens = word_tokenize(text)
    # Remove stop words
    stop_words = set(stopwords.words('english'))
    tokens = [token for token in tokens if token.lower() not in stop_words]
    # Remove punctuation
    tokens = [token for token in tokens if token not in string.punctuation]
    # Calculate word frequency
    freq = defaultdict(int)
    for token in tokens:
        freq[token] += 1
    # Calculate weighted frequency
    max_freq = max(freq.values())
    for token in freq.keys():
        freq[token] /= max_freq
    # Calculate sentence scores
    sentence_scores = defaultdict(int)
    for sentence in nltk.sent_tokenize(text):
        for token in nltk.word_tokenize(sentence.lower()):
            if token in freq:
                sentence_scores[sentence] += freq[token]
    # Get top 3 sentences
    summary_sentences = nlargest(3, sentence_scores, key=sentence_scores.get)
    # Combine summary sentences
    summary = ' '.join(summary_sentences)
    return summary

# FIND RELATED PDFS TO THE PATIENT:
    # Function to preprocess text using spacy
def preprocess_text(text):
    doc = nlp(text)
    processed_text = " ".join([token.lemma_ for token in doc if not token.is_stop])
    return processed_text


    # Function to find the best matching PDFs for a query
def find_related_pdfs(query, directory):
    query = preprocess_text(query)
    tfidf_vectorizer = TfidfVectorizer()
    documents = []
    file_names = []
    file_paths = []  # Added file_paths list to store file paths

    # Iterate over PDF files in the directory
    for file in os.listdir(directory):
        if file.endswith(".pdf"):
            file_path = os.path.join(directory, file)
            text = extract_text_from_pdf(file_path)
            processed_text = preprocess_text(text)
            documents.append(processed_text)
            file_names.append(file)
            file_paths.append(file_path)  # Store the file path

    # Calculate TF-IDF matrix for the documents
    tfidf_matrix = tfidf_vectorizer.fit_transform(documents)

    # Calculate similarity between the query and each document
    query_vector = tfidf_vectorizer.transform([query])
    similarities = cosine_similarity(query_vector, tfidf_matrix)[0]

    # Sort the documents by similarity score
    sorted_indices = similarities.argsort()[::-1]

    # Return the top matching PDFs with the most relatable phrase containing the search term
    top_matches = []
    for index in sorted_indices:

        # Find the most relatable sentence containing the search term
        sentences = nltk.sent_tokenize(documents[index])
        relatable_sentence = None
        max_tfidf_score = -1

        for sentence in sentences:
            # Filter out static information (e.g., patient name, date of birth, etc.)
            if "Summary:" in sentence:
                continue
            if "Date de naissance :" in sentence:
                continue
            if "Date de naissance :" in sentence:
                continue
            if "Sexe :" in sentence:
                continue
            if "Adresse :" in sentence:
                continue

            sentence_vector = tfidf_vectorizer.transform([sentence])
            tfidf_score = cosine_similarity(query_vector, sentence_vector)[0][0]
            if tfidf_score > max_tfidf_score:
                max_tfidf_score = tfidf_score
                relatable_sentence = sentence

        # If no relevant sentence was found, use the first sentence
        if relatable_sentence is None and len(sentences) > 0:
            relatable_sentence = sentences[0]

        match = {
            "file_name": file_names[index],
            "file_path": file_paths[index],  # Include the file path
            "date de la consultation": datetime.fromtimestamp(os.path.getmtime(file_paths[index])).strftime('%Y-%m-%d'),
            "relatable_sentence": '...'+relatable_sentence+'...'
        }

        top_matches.append(match)

    return top_matches



def extract_info_from_first_pdf(pdf_path):
    patient_info = {
        "nom_patient": "N/A",
        "date_naissance": "N/A",
        "sexe": "N/A",
        "adresse": "N/A"
    }

    # Open the PDF file
    with open(pdf_path, "rb") as file:
        pdf_reader = PyPDF4.PdfFileReader(file)
        if pdf_reader.numPages > 0:
            # Read the first page of the PDF
            page = pdf_reader.getPage(0)
            text = page.extractText()

            # Extract patient information from the text
            if "Nom du patient :" in text:
                start_index = text.index("Nom du patient :") + len("Nom du patient :")
                end_index = text.find("Date de naissance :", start_index)
                patient_info["nom_patient"] = text[start_index:end_index].strip()

            if "Date de naissance :" in text:
                start_index = text.index("Date de naissance :") + len("Date de naissance :")
                end_index = text.find("Sexe :", start_index)
                patient_info["date_naissance"] = text[start_index:end_index].strip()

            if "Sexe :" in text:
                start_index = text.index("Sexe :") + len("Sexe :")
                end_index = text.find("Adresse :", start_index)
                patient_info["sexe"] = text[start_index:end_index].strip()

            if "Adresse :" in text:
                start_index = text.index("Adresse :") + len("Adresse :")
                patient_info["adresse"] = text[start_index:].strip()

    return patient_info


#TEST GET STATIC INFO FROM A PDF:

#folder_path = 'Patients/DMP Marie MARTIN/FMP1 Marie Martin.pdf'
#print(extract_info_from_first_pdf(folder_path))
